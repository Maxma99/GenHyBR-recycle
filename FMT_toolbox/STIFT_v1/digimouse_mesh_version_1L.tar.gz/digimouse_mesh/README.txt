Digimouse atlas FEM mesh - Version 1L (low-resolution).

Created on 02/11/2011 by Qianqian Fang [1] with iso2mesh version 1.0.0 [2]
and CGAL [3]. The image segmentation was downloaded from [4].

License: 
	public domain
Format: 
        node: node coordinates (in mm)
        face: surface triangles, the last column is the tissue surface ID, 
        elem: tetrahedral elements, the last column is the region ID, 
Other files:
        digimouse_tissue_index.txt:   tissue index for the original atlas segmentation
                                      this should match the last column of elem
        digimouse_optical_properties.dat: tissue optical properties, in the order of
                                      [mua (1/mm), mus (1/mm), anisotropy, refractive index] 
        digimouse_mesh.m:    mesh generation script to create this mesh using iso2mesh 1.0

URL: http://mcx.sourceforge.net/cgi-bin/index.cgi?MMC/DigimouseMesh

Links:
 [1] http://nmr.mgh.harvard.edu/~fangq/
 [2] http://iso2mesh.sf.net
 [3] http://www.cgal.org/
 [4] http://neuroimage.usc.edu/Digimouse_download.html

Related Citations:
 [iso2mesh]: Q. Fang and D. Boas, "Tetrahedral mesh generation from volumetric binary and gray-scale images," 
             Proceedings of IEEE International Symposium on Biomedical Imaging 2009, pp. 1142-1145, 2009
 [CGAL]:     L. Rineau, S. Tayeb, and M. Yvinec. 3D Mesh Generation. In CGAL Editorial Board, 
             Ed, CGAL User and Reference Manual. 3.5 edition, 2009
 [Digimouse]:B. Dogdas, D. Stout, A. Chatziioannou, and R. M. Leahy, "Digimouse: A 3D Whole Body Mouse 
             Atlas from CT and Cryosection Data." Phys Med Biol. 52 (3): 577-87, 2007

